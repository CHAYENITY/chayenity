"""This module defines specific functions for GeoPackage dialect."""

from geoalchemy2.types.dialects.sqlite import bind_processor_process  # noqa
