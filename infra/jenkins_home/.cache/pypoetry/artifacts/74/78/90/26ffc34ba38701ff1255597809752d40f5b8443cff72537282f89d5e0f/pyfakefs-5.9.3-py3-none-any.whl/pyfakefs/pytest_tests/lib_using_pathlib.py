import pathlib


def use_pathlib(path: str):
    return pathlib.Path(path)
